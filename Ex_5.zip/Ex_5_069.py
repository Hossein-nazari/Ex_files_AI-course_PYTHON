index=int(input('Enter a number between 0 to 4  : '))
tup1=('iran','italy','germany','usa','canada')
if  0<=index<=4 :
    print(tup1[index])
else:
    print('wrong number')