total=0
print (total)
while total<50:
    i=int(input('Enter a number : '))
    total+=i
    print('the total is ',total)
