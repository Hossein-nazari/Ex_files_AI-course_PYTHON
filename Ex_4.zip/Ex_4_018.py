num=int(input('choose a number from 1,2 and 3  '))
if num == 1:
    print("thank you")
elif num==2:
    print('well done')
elif num ==3:
    print("correct")
else:
    print('Error massage :|')