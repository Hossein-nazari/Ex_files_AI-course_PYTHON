i=int(input('Enter a number : '))
while i<5:
    i=int(input('Enter a number : '))
print ('the last number you have entered was ',i)
