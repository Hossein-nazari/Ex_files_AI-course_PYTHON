num1=int(input('Enter a num between 10 to 20: '))
if 10<num1<=20:
    print('Thank you! :)')
else:
    print('Incorrect answer')