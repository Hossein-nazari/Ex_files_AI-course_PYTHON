str1=input('Enter you favourite color ')
if (str1=="red") or (str1=="Red") or (str1=="RED"):
    print('I like red too :)')
else:
    print("i don't like {}, I prefer red".format(str1))