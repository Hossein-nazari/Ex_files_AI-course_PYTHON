num=int(input('please enter a number '))
if num < 10:
    print("too low")
elif 10<=num<=20:
    print('correct')
else:
    print("too high")

