num1=int(input('Enter a num less than 20: '))
if num1>=20:
    print('Too high :|')
else:
    print('Thank you! :)')