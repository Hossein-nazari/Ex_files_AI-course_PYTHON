age=int(input('please enter you age ')
        
"""
if True:
    print('you can vote')
elif age==17:
    print('you can learn driving')
elif age==16:
    print ('you can buy a lottery ticket')
elif age<16:
    print ('you can go Trick or Treating')
"""