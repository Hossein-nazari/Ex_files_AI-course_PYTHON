i=input('please enter your favorite sport  ')
l1=['swimming','running']
l1.append(i)
l1.sort()
print(l1)