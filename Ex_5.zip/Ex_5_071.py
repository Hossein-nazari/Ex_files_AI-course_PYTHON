l1=['phisics','math','algebra','literature','biology','english']
print (l1)
sub=input("which subject you don't like it ?  ")
sub=sub.lower()
l1.remove(sub)
print (l1)